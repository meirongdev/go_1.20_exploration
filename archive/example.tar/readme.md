# Go1.20 Exploration

## Preparation

- install gvm 
- install go1.19.13 and go1.20.9 by gvm
